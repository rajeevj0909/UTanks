import pyglet
#Sets window dimensions
window_w=1280
window_h=720
window=pyglet.window.Window(width=window_w,height=window_h)

#Run Window
pyglet.app.run()
